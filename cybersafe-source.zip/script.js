
"use strict";

const $ = (id) => document.getElementById(id);

const pages = [
  "dashboard",
  "password",
  "inspector",
  "tips",
  "about"
];

const titles = {
  dashboard: "Your digital safety.",
  password: "Create stronger passwords.",
  inspector: "Pause before you click.",
  tips: "Build safer digital habits.",
  about: "Security without fake promises."
};

let generatedPassword = "";
let toastTimer;

function toast(message) {
  const element = $("toast");
  element.textContent = message;
  element.classList.add("show");

  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => {
    element.classList.remove("show");
  }, 2400);
}

// Navigation
function showPage(page) {
  if (!pages.includes(page)) return;

  pages.forEach((name) => {
    $(name).classList.toggle("hidden", name !== page);
  });

  document.querySelectorAll("[data-page]").forEach((button) => {
    button.classList.toggle("active", button.dataset.page === page);
  });

  $("page-title").textContent = titles[page];
  window.scrollTo({ top: 0, behavior: "smooth" });
}

document.querySelectorAll("[data-page]").forEach((button) => {
  button.addEventListener("click", () => {
    showPage(button.dataset.page);
  });
});

document.querySelectorAll("[data-open]").forEach((button) => {
  button.addEventListener("click", () => {
    showPage(button.dataset.open);
  });
});

$("quick-generate").addEventListener("click", () => {
  showPage("password");
  generatePassword();
});

// Password generator
$("length").addEventListener("input", () => {
  $("length-value").textContent = $("length").value;
});

function randomIndex(max) {
  if (!Number.isInteger(max) || max < 1) {
    throw new Error("Invalid random range.");
  }

  // Rejection sampling avoids modulo bias.
  const range = 0x100000000;
  const limit = Math.floor(range / max) * max;
  const numbers = new Uint32Array(1);

  {let __lp0=Date.now();do {if(Date.now()-__lp0>400){throw new Error("Preview stopped: a loop ran longer than 400ms — check for an infinite loop.");}
    crypto.getRandomValues(numbers);
  } while (numbers[0] >= limit);}

  return numbers[0] % max;
}

function generatePassword() {
  if (!window.crypto?.getRandomValues) {
    toast("Secure random generation is unavailable.");
    return;
  }

  const sets = [];

  if ($("lower").checked) {
    sets.push("abcdefghijklmnopqrstuvwxyz");
  }

  if ($("upper").checked) {
    sets.push("ABCDEFGHIJKLMNOPQRSTUVWXYZ");
  }

  if ($("numbers").checked) {
    sets.push("0123456789");
  }

  if ($("symbols").checked) {
    sets.push("!@#$%^&*()-_=+[]{}:,.?");
  }

  if (sets.length === 0) {
    toast("Select at least one character set.");
    return;
  }

  const length = Number($("length").value);
  const allCharacters = sets.join("");
  const characters = [];

  // Ensure every selected character set is represented.
  sets.forEach((set) => {
    characters.push(set[randomIndex(set.length)]);
  });

  {let __lp1=Date.now();while (characters.length < length) {if(Date.now()-__lp1>400){throw new Error("Preview stopped: a loop ran longer than 400ms — check for an infinite loop.");}
    characters.push(
      allCharacters[randomIndex(allCharacters.length)]
    );
  }}

  // Cryptographically random Fisher-Yates shuffle.
  {let __lp2=Date.now();for (let i = characters.length - 1; i > 0; i--) {if(Date.now()-__lp2>400){throw new Error("Preview stopped: a loop ran longer than 400ms — check for an infinite loop.");}
    const j = randomIndex(i + 1);
    [characters[i], characters[j]] =
      [characters[j], characters[i]];
  }}

  generatedPassword = characters.slice(0, length).join("");
  $("password-output").value = generatedPassword;

  const entropy = Math.floor(
    length * Math.log2(allCharacters.length)
  );

  $("password-status").textContent =
    `Generated locally. Estimated search space: ${entropy} bits. ` +
    "Use a unique password for every account.";

  toast("New password generated.");
}

$("generate").addEventListener("click", generatePassword);

// Copy generated password
$("copy-password").addEventListener("click", async () => {
  if (!generatedPassword) {
    toast("Generate a password first.");
    return;
  }

  try {
    await navigator.clipboard.writeText(generatedPassword);
    toast("Password copied.");
  } catch {
    // Fallback for browsers with limited clipboard support.
    const field = $("password-output");
    field.focus();
    field.select();

    try {
      const success = document.execCommand("copy");
      toast(success ? "Password copied." : "Copy was blocked.");
    } catch {
      toast("Copy blocked. Select and copy the password manually.");
    }

    field.setSelectionRange(0, 0);
  }
});

// Escape untrusted strings before placing them in HTML.
function escapeHTML(value) {
  return String(value).replace(/[&<>"']/g, (character) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  })[character]);
}

// URL pattern inspector. This is not a threat-intelligence scan.
function inspectURL(input) {
  let candidate = input.trim();

  if (!candidate) {
    return { error: "Enter a website URL." };
  }

  if (!/^[a-zA-Z][a-zA-Z\d+.-]*:/.test(candidate)) {
    candidate = "https://" + candidate;
  }

  let url;

  try {
    url = new URL(candidate);
  } catch {
    return {
      error: "Invalid URL. Check the address and try again."
    };
  }

  const findings = [];
  const hostname = url.hostname.toLowerCase();

  function flag(level, title, detail) {
    findings.push({ level, title, detail });
  }

  if (!["http:", "https:"].includes(url.protocol)) {
    flag(
      "bad",
      "Unexpected protocol",
      `The address uses ${url.protocol}, not a standard web protocol.`
    );
  }

  if (url.protocol === "http:") {
    flag(
      "warn",
      "HTTPS is not enabled",
      "HTTP does not provide HTTPS transport encryption."
    );
  }

  if (url.username || url.password) {
    flag(
      "bad",
      "Credentials in URL",
      "The address contains embedded username or password fields."
    );
  }

  if (hostname.split(".").some(part => part.startsWith("xn--"))) {
    flag(
      "warn",
      "Internationalized hostname",
      "Check carefully for lookalike characters in the domain."
    );
  }

  if (/^\d{1,3}(\.\d{1,3}){3}$/.test(hostname)) {
    flag(
      "warn",
      "Numeric hostname",
      "The address uses an IPv4-style hostname. Verify the source."
    );
  }

  if (hostname.split(".").length >= 5) {
    flag(
      "warn",
      "Many subdomain levels",
      "Read the hostname carefully to identify the actual domain."
    );
  }

  if (hostname.length > 50) {
    flag(
      "warn",
      "Long hostname",
      "Long hostnames can make deceptive domains harder to notice."
    );
  }

  if (url.port && !["80", "443"].includes(url.port)) {
    flag(
      "warn",
      "Nonstandard port",
      `The address specifies port ${url.port}. Verify why it is needed.`
    );
  }

  if (/(login|verify|account|password|wallet|payment)/i.test(hostname)) {
    flag(
      "warn",
      "Account-related wording",
      "Account-related words occur in the hostname. This alone does not prove fraud."
    );
  }

  if ((url.search + url.hash).length > 150) {
    flag(
      "warn",
      "Long URL parameters",
      "The URL may contain sensitive tokens. Avoid sharing it publicly."
    );
  }

  if (findings.length === 0) {
    flag(
      "good",
      "No obvious pattern flags",
      "This limited check found no configured warning patterns. The site is not verified as safe."
    );
  }

  return { url, findings };
}

$("url-form").addEventListener("submit", (event) => {
  event.preventDefault();

  const resultElement = $("url-result");
  const result = inspectURL($("url-input").value);

  resultElement.classList.remove("hidden");

  if (result.error) {
    resultElement.className = "result";
    resultElement.innerHTML =
      `<strong>Unable to inspect URL</strong><p>${escapeHTML(result.error)}</p>`;
    return;
  }

  const hasBad = result.findings.some(f => f.level === "bad");
  const hasWarning = result.findings.some(f => f.level === "warn");

  resultElement.className = "result";

  if (hasBad) {
    resultElement.style.borderColor = "#ff9ca8";
  } else if (hasWarning) {
    resultElement.style.borderColor = "#ffd38a";
  } else {
    resultElement.style.borderColor = "#87f0c0";
  }

  const heading = hasBad
    ? "Warning signs found"
    : hasWarning
      ? "Review this URL carefully"
      : "No obvious pattern flags";

  resultElement.innerHTML = `
    <h3>${heading}</h3>
    <p><strong>Hostname:</strong> ${escapeHTML(result.url.hostname)}</p>
    <p><strong>Protocol:</strong> ${escapeHTML(result.url.protocol)}</p>
    <div class="findings">
      ${result.findings.map(f => `
        <article class="tip">
          <strong>${escapeHTML(f.title)}</strong>
          <p>${escapeHTML(f.detail)}</p>
        </article>
      `).join("")}
    </div>
    <p class="notice">
      This is a local heuristic, not a live security scan.
      No reputation database was queried. Never treat a clean
      result as proof that a website is safe.
    </p>
  `;
});

// Clear URL inspector
$("clear-url").addEventListener("click", () => {
  $("url-input").value = "";
  $("url-result").classList.add("hidden");
  $("url-result").replaceChildren();
  $("url-input").focus();
});

// Reset page state
$("reset-app").addEventListener("click", () => {
  generatedPassword = "";
  $("password-output").value = "";
  $("password-status").textContent =
    "Choose your options and generate a password.";

  $("url-input").value = "";
  $("url-result").classList.add("hidden");
  $("url-result").replaceChildren();

  $("length").value = 20;
  $("length-value").textContent = "20";

  $("lower").checked = true;
  $("upper").checked = true;
  $("numbers").checked = true;
  $("symbols").checked = true;

  showPage("dashboard");
  toast("Page state reset.");
});

// Create a small, uncompressed ZIP archive without external libraries.
function createZip(files) {
  const encoder = new TextEncoder();
  const crc32 = (bytes) => {
    let crc = 0xffffffff;
    {let __lp3=Date.now();for (const byte of bytes) {if(Date.now()-__lp3>400){throw new Error("Preview stopped: a loop ran longer than 400ms — check for an infinite loop.");}
      crc ^= byte;
      {let __lp4=Date.now();for (let bit = 0; bit < 8; bit++) {if(Date.now()-__lp4>400){throw new Error("Preview stopped: a loop ran longer than 400ms — check for an infinite loop.");}
        crc = (crc >>> 1) ^ (crc & 1 ? 0xedb88320 : 0);
      }}
    }}
    return (crc ^ 0xffffffff) >>> 0;
  };
  const word = (value) => {
    const bytes = new Uint8Array(2);
    new DataView(bytes.buffer).setUint16(0, value, true);
    return bytes;
  };
  const dword = (value) => {
    const bytes = new Uint8Array(4);
    new DataView(bytes.buffer).setUint32(0, value >>> 0, true);
    return bytes;
  };
  const join = (parts) => {
    const result = new Uint8Array(parts.reduce((sum, part) => sum + part.length, 0));
    let offset = 0;
    {let __lp5=Date.now();for (const part of parts) {if(Date.now()-__lp5>400){throw new Error("Preview stopped: a loop ran longer than 400ms — check for an infinite loop.");}
      result.set(part, offset);
      offset += part.length;
    }}
    return result;
  };

  const localParts = [];
  const centralParts = [];
  let localOffset = 0;

  {let __lp6=Date.now();for (const file of files) {if(Date.now()-__lp6>400){throw new Error("Preview stopped: a loop ran longer than 400ms — check for an infinite loop.");}
    const name = encoder.encode(file.name);
    const data = encoder.encode(file.content);
    const checksum = crc32(data);
    const localHeader = join([
      dword(0x04034b50), word(20), word(0x0800), word(0),
      word(0), word(0), dword(checksum), dword(data.length),
      dword(data.length), word(name.length), word(0), name
    ]);
    const centralHeader = join([
      dword(0x02014b50), word(20), word(20), word(0x0800), word(0),
      word(0), word(0), dword(checksum), dword(data.length),
      dword(data.length), word(name.length), word(0), word(0),
      word(0), word(0), dword(0), dword(localOffset), name
    ]);

    localParts.push(localHeader, data);
    centralParts.push(centralHeader);
    localOffset += localHeader.length + data.length;
  }}

  const centralDirectory = join(centralParts);
  const endRecord = join([
    dword(0x06054b50), word(0), word(0), word(files.length),
    word(files.length), dword(centralDirectory.length), dword(localOffset),
    word(0)
  ]);

  return join([...localParts, centralDirectory, endRecord]);
}

$("download-source").addEventListener("click", async (event) => {
  const button = event.currentTarget;
  button.disabled = true;

  try {
    const names = ["index.html", "styles.css", "script.js"];
    const files = await Promise.all(names.map(async (name) => {
      const response = await fetch(new URL(name, window.location.href));
      if (!response.ok) {
        throw new Error(`Could not load ${name}.`);
      }
      return { name, content: await response.text() };
    }));

    const archive = createZip(files);
    const objectURL = URL.createObjectURL(
      new Blob([archive], { type: "application/zip" })
    );
    const link = document.createElement("a");
    link.href = objectURL;
    link.download = "cybersafe-source.zip";
    link.click();
    setTimeout(() => URL.revokeObjectURL(objectURL), 1000);
    toast("Source ZIP downloaded.");
  } catch (error) {
    toast(error.message || "Could not create the source ZIP.");
  } finally {
    button.disabled = false;
  }
});
